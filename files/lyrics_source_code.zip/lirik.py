"""
Lyric Display Animation
Copyright (c) 2025 Fazal Said

Author: Fazal Said
Instagram: @fazallsaid
Tiktok: @fazallsaid
Website: fazallsaid.github.io

This script creates a typing animation effect for displaying lyrics
with customizable typing speed and line delays. It maintains previous
lines visible while adding new lines with animation.
"""

import time
import os
import sys

def type_text(text, typing_speed=0.1):
    """
    Display text with a typing animation effect without clearing screen.
    
    Args:
        text (str): The text to be displayed
        typing_speed (float): Speed of typing in seconds per character
    """
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(typing_speed)
    print()  # Add a new line at the end

def display_lyrics(lyrics, typing_speed=0.1, line_delay=1.0):
    """
    Display multiple lines of lyrics with typing animation, keeping previous lines visible.
    
    Args:
        lyrics (list): List of lyric lines
        typing_speed (float): Speed of typing in seconds per character
        line_delay (float): Delay between lines in seconds
    """
    # Clear screen only once at the start
    os.system('cls' if os.name == 'nt' else 'clear')
    
    # Print header
    print("\n" + "=" * 40)
    print("🎵 Kita Usahakan Lagi 🎵".center(40))
    print("=" * 40 + "\n")
    
    # Keep track of displayed lines
    displayed_lines = []
    
    for line in lyrics:
        # Add new line to displayed lines
        displayed_lines.append(line)
        
        # Clear screen and redisplay all lines
        os.system('cls' if os.name == 'nt' else 'clear')
        
        # # Reprint header
        # print("\n" + "=" * 40)
        # print("🎵 Lirik Lagu 🎵".center(40))
        # print("=" * 40 + "\n")
        
        # Display all previous lines
        for prev_line in displayed_lines[:-1]:
            print(prev_line)
        
        # Type the current line with animation
        type_text(line, typing_speed)
        time.sleep(line_delay)

# Example usage
if __name__ == "__main__":
    # Sample lyrics - you can replace these with your own
    sample_lyrics = [
        "Jika tidak hari ini, mungkin minggu depan",
        "Jika tidak minggu ini, mungkin bulan depan",
        "Jika tidak bulan ini, mungkin tahun depan"
    ]
    
    # Display the lyrics with custom speed
    display_lyrics(
        sample_lyrics,
        typing_speed=0.1,  # Speed of typing (seconds per character)
        line_delay=1.0     # Delay between lines (seconds)
    )
